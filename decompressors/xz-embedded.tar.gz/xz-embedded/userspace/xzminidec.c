// SPDX-License-Identifier: 0BSD

/*
 * Simple XZ decoder command line tool
 * Modified for temsxz style (minimal, no verbose output)
 */

#include <stdbool.h>
#include <stdio.h>
#include <string.h>
#include "xz.h"

#ifndef DICT_SIZE_MAX
#	define DICT_SIZE_MAX (64U << 20)
#endif

static uint8_t in[BUFSIZ];
static uint8_t out[BUFSIZ];

int main(int argc, char **argv)
{
	struct xz_buf b;
	struct xz_dec *s;
	enum xz_ret ret;
	int quiet = 0;
	
	/* Vérifier l'option -q pour quiet mode (pas de messages) */
	if (argc >= 2 && strcmp(argv[1], "-q") == 0) {
		quiet = 1;
	}

	xz_crc32_init();

	s = xz_dec_init(XZ_DYNALLOC, DICT_SIZE_MAX);
	if (s == NULL) {
		if (!quiet) fprintf(stderr, "Error: Cannot initialize decoder\n");
		return 1;
	}

	b.in = in;
	b.in_pos = 0;
	b.in_size = 0;
	b.out = out;
	b.out_pos = 0;
	b.out_size = sizeof(out);

	while (true) {
		if (b.in_pos == b.in_size) {
			b.in_size = fread(in, 1, sizeof(in), stdin);

			if (ferror(stdin)) {
				if (!quiet) fprintf(stderr, "Error: Read failed\n");
				xz_dec_end(s);
				return 1;
			}

			b.in_pos = 0;
		}

		ret = xz_dec_catrun(s, &b, b.in_size == 0);

		if (b.out_pos == sizeof(out)) {
			if (fwrite(out, 1, b.out_pos, stdout) != b.out_pos) {
				if (!quiet) fprintf(stderr, "Error: Write failed\n");
				xz_dec_end(s);
				return 1;
			}
			b.out_pos = 0;
		}

		if (ret == XZ_OK)
			continue;

		if (ret == XZ_UNSUPPORTED_CHECK) {
			/* Check non supporté, on continue quand même */
			continue;
		}

		if (fwrite(out, 1, b.out_pos, stdout) != b.out_pos) {
			if (!quiet) fprintf(stderr, "Error: Write failed\n");
			xz_dec_end(s);
			return 1;
		}

		switch (ret) {
		case XZ_STREAM_END:
			xz_dec_end(s);
			return 0;

		case XZ_MEM_ERROR:
			if (!quiet) fprintf(stderr, "Error: Out of memory\n");
			break;

		case XZ_MEMLIMIT_ERROR:
			if (!quiet) fprintf(stderr, "Error: Dictionary too large\n");
			break;

		case XZ_FORMAT_ERROR:
			if (!quiet) fprintf(stderr, "Error: Not a valid XZ file\n");
			break;

		case XZ_OPTIONS_ERROR:
			if (!quiet) fprintf(stderr, "Error: Unsupported options\n");
			break;

		case XZ_DATA_ERROR:
		case XZ_BUF_ERROR:
			if (!quiet) fprintf(stderr, "Error: Corrupted data\n");
			break;

		default:
			if (!quiet) fprintf(stderr, "Error: Decompression failed (%d)\n", ret);
			break;
		}

		xz_dec_end(s);
		return 1;
	}
}

